import pystray
from PIL import Image
from frameworks.telegram import sendcommand as send
from frameworks.ConfigReaderFile import readconfig as rc
from frameworks.loading import resource_path as path


def exitm(icon):
	icon.stop()


commands = rc().get('COMMANDS')
menu = [pystray.MenuItem("Exit", exitm)]
for i in commands:
	menu.append(pystray.MenuItem(i, send))

image = Image.open(path("frameworks\\ico.png"))

icon = pystray.Icon("GFG", image, "Phone", menu=pystray.Menu(*tuple(menu)))

icon.run()
