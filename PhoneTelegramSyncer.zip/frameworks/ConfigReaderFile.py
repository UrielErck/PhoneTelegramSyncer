def gettext(paramname: str, text: str) -> str:
    lenght = len(paramname)
    fintext = text[text.find(f'### {paramname} ###')+lenght+8:text.find(f'&& {paramname} &&')]
    return fintext


def readconfig() -> dict:
    from frameworks.loading import resource_path as path
    findata = {}
    temp = {}
    file = open(path(f'frameworks\\config'), 'r')
    text = file.read()
    variabletext = gettext('MAIN VARIABLE', text)
    commandstext = gettext('COMMANDS', text)
    for i in variabletext.split('\n'):
        if '=' in i:
            name = i[0:i.find('=')-1]
            value = i[i.find('=')+2:]
            temp.update({name: value})
    findata.update({'MVARIABLE': temp})
    temp = []
    for i in commandstext.split('\n'):
        if i:
            temp.append(i)
    findata.update({'COMMANDS': temp})
    return findata
